import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:snapcal/core/services/config_service.dart';
import 'package:snapcal/data/services/notification_service.dart';
import '../../data/models/meal.dart';
import '../../data/models/user_settings.dart';
import '../../data/models/water_log.dart';
import '../../data/models/body_metric.dart';
import '../../data/models/grocery_item.dart';
import '../../data/models/meal_plan.dart';
import '../../data/models/meal_template.dart';
import '../../data/models/achievement.dart';
import '../../data/repositories/settings_repository.dart';
import '../../data/services/gemini_service.dart';
import '../../data/services/barcode_service.dart';
import '../../data/services/subscription_service.dart';
import '../../data/services/scan_gate_service.dart';
import '../../data/services/premium_gate_service.dart';
import '../../data/services/promotional_paywall_service.dart';
import '../../data/services/sync_queue_service.dart';
import '../../data/services/upload_queue_service.dart';
import '../../data/services/fcm_service.dart';
import '../../data/services/widget_service.dart';
import 'app_lifecycle_service.dart';
import '../utils/async_guard.dart';

class AppInitializer {
  static bool _errorReportingConfigured = false;
  static bool _lifecycleRecoveryConfigured = false;

  static Future<void> preInit() async {
    await _initFirebase();
  }

  static Future<void> init() async {
    final startTime = DateTime.now();
    debugPrint('🚀 AppInitializer: Starting initialization...');

    try {
      debugPrint('🚀 AppInitializer: Setting System UI...');
      AppLifecycleService().init();
      _configureLifecycleRecovery();
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      SystemChrome.setSystemUIOverlayStyle(
        const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          systemNavigationBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
          systemNavigationBarIconBrightness: Brightness.light,
        ),
      );

      debugPrint('🚀 AppInitializer: Initializing Firebase...');
      await _initFirebase();

      debugPrint('🚀 AppInitializer: Initializing Hive...');
      await _initHive();

      debugPrint('🚀 AppInitializer: Starting background services...');
      unawaited(_initBackgroundServices());

      final duration = DateTime.now().difference(startTime).inMilliseconds;
      debugPrint('✅ AppInitializer: Critical core ready in ${duration}ms');
    } catch (e, stack) {
      _logInitializerFailure(e, stack);
      _recordInitializerFailure(e, stack);
      debugPrint(stack.toString());
      rethrow;
    }
  }

  static Future<void> _initBackgroundServices() async {
    await _runOptionalBackgroundService(
      'Remote config init',
      () => ConfigService().init().timeout(const Duration(seconds: 10)),
    );

    await Future.wait([
      _runOptionalBackgroundService('Scan gate init', ScanGateService().init),
      _runOptionalBackgroundService('FCM init', FcmService().init),
      _runOptionalBackgroundService(
        'Premium gate init',
        PremiumGateService().init,
      ),
      _runOptionalBackgroundService(
        'Promotional paywall init',
        PromotionalPaywallService.instance().init,
      ),
      _runOptionalBackgroundService('Sync queue init', SyncQueueService().init),
      _runOptionalBackgroundService(
        'Upload queue init',
        UploadQueueService().init,
      ),
      _runOptionalBackgroundService('Notification init', () async {
        await NotificationService().init();
      }),
      _runOptionalBackgroundService('Subscription init', () async {
        final repo = SettingsRepository();
        await repo.init();
        await SubscriptionService.init(repo);
      }),
      _runOptionalBackgroundService('Widget init', WidgetService.init),
      _runOptionalBackgroundService(
        'Sync queue flush',
        () => SyncQueueService().flushDue(),
      ),
      _runOptionalBackgroundService(
        'Upload queue flush',
        () => UploadQueueService().flushDue(),
      ),
      _runOptionalBackgroundService('Service warmup', _warmupSingletons),
    ]);
    debugPrint('⚡ Background services ready');
  }

  static Future<void> _runOptionalBackgroundService(
    String name,
    Future<void> Function() task,
  ) async {
    try {
      await runSilently(name, task).timeout(const Duration(seconds: 12));
    } catch (e, stack) {
      debugPrint('⚠️ AppInitializer: optional service "$name" failed: $e');
      if (Firebase.apps.isNotEmpty) {
        FirebaseCrashlytics.instance.recordError(
          e,
          stack,
          fatal: false,
          reason: 'Optional background service failed: $name',
        );
      }
    }
  }

  static Future<void> _warmupSingletons() async {
    AIService();
    BarcodeService();
    debugPrint('⚡ Services warmed up');
  }

  static void _configureLifecycleRecovery() {
    if (_lifecycleRecoveryConfigured) return;
    _lifecycleRecoveryConfigured = true;

    AppLifecycleService().addListener(() {
      final lifecycle = AppLifecycleService();
      if (!lifecycle.isResumed) return;
      unawaited(
        _runOptionalBackgroundService(
          'Lifecycle sync queue flush',
          () => SyncQueueService().flushDue(),
        ),
      );
      unawaited(
        _runOptionalBackgroundService(
          'Lifecycle upload queue flush',
          () => UploadQueueService().flushDue(),
        ),
      );
      unawaited(
        _runOptionalBackgroundService(
          'Lifecycle subscription verify',
          () async {
            await SubscriptionService().verifyCurrentEntitlement();
          },
        ),
      );
    });
  }

  static Future<void> _initFirebase() async {
    try {
      debugPrint('🔥 Firebase: Checking if already initialized...');
      if (Firebase.apps.isEmpty) {
        debugPrint('🔥 Firebase: Calling initializeApp()...');
        await Firebase.initializeApp().timeout(const Duration(seconds: 30));
        debugPrint('🔥 Firebase: initializeApp() completed');
      } else {
        debugPrint('🔥 Firebase already initialized');
      }
      await FirebaseAppCheck.instance.activate(
        providerAndroid:
            kDebugMode
                ? const AndroidDebugProvider()
                : const AndroidPlayIntegrityProvider(),
        providerApple:
            kDebugMode
                ? const AppleDebugProvider()
                : const AppleAppAttestProvider(),
      );
      await _configureCrashlyticsAfterFirebase();
    } catch (e) {
      _logFirebaseInitFailure(e);
      // Rethrow to ensure the UI shows the retry screen instead of hanging in a half-initialized state
      rethrow;
    }
  }

  static Future<void> _configureCrashlyticsAfterFirebase() async {
    // Enable Crashlytics in Release mode
    if (!kDebugMode) {
      debugPrint('🔥 Firebase: Enabling Crashlytics collection...');
      await FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(true);
      debugPrint('🔥 Firebase: Crashlytics collection enabled');
    }

    if (_errorReportingConfigured) {
      debugPrint('🔥 Firebase: Error reporting already configured');
      return;
    }

    // Setup Global Error Handling now that Firebase is ready
    debugPrint('🔥 Firebase: Setting up error reporting...');
    _setupErrorReporting();
    _errorReportingConfigured = true;

    debugPrint('🔥 Firebase initialized and Error Reporting active');
  }

  static void _setupErrorReporting() {
    FlutterError.onError = (errorDetails) {
      final fatal = _shouldRecordFlutterErrorAsFatal(
        errorDetails.exception,
        errorDetails.stack,
      );
      unawaited(
        FirebaseCrashlytics.instance.setCustomKey('flutter_error_fatal', fatal),
      );

      if (fatal) {
        FirebaseCrashlytics.instance.recordFlutterFatalError(errorDetails);
      } else {
        FirebaseCrashlytics.instance.recordFlutterError(errorDetails);
      }

      FlutterError.presentError(errorDetails);
    };

    PlatformDispatcher.instance.onError = (error, stack) {
      final fatal = _shouldRecordFlutterErrorAsFatal(error, stack);
      FirebaseCrashlytics.instance.recordError(error, stack, fatal: fatal);
      return true;
    };
    debugPrint('🛡️ Crashlytics Error Reporting configured');
  }

  static bool _shouldRecordFlutterErrorAsFatal(
    Object error,
    StackTrace? stack,
  ) {
    return !_isNonFatalMouseTrackerAssertion(error, stack) &&
        !_isParentDataWidgetAssertion(error, stack);
  }

  static bool _isNonFatalMouseTrackerAssertion(
    Object error,
    StackTrace? stack,
  ) {
    final message = error.toString();
    final stackText = stack?.toString() ?? '';

    return message.contains('mouse_tracker.dart') ||
        message.contains('!_debugDuringDeviceUpdate') ||
        stackText.contains('MouseTracker.updateAllDevices');
  }

  static bool _isParentDataWidgetAssertion(Object error, StackTrace? stack) {
    final message = error.toString();
    final stackText = stack?.toString() ?? '';

    return message.contains('Incorrect use of ParentDataWidget') ||
        message.contains('ParentDataWidget') ||
        stackText.contains('RenderObjectElement._updateParentData');
  }

  static void _logInitializerFailure(Object error, StackTrace stack) {
    debugPrint('❌ AppInitializer: Fatal error during initialization');
    debugPrint('❌ AppInitializer: type=${error.runtimeType}');
    if (error is PlatformException) {
      debugPrint('❌ AppInitializer: platformCode=${error.code}');
      debugPrint('❌ AppInitializer: platformMessage=${error.message}');
      debugPrint('❌ AppInitializer: platformDetails=${error.details}');
      if (error.code == 'channel-error') {
        _logNativePluginChannelFailure('AppInitializer');
      }
    } else {
      debugPrint('❌ AppInitializer: error=$error');
    }
    debugPrint('❌ AppInitializer: firebaseApps=${Firebase.apps.length}');
  }

  static void _recordInitializerFailure(Object error, StackTrace stack) {
    if (Firebase.apps.isEmpty) return;

    unawaited(
      FirebaseCrashlytics.instance.setCustomKey(
        'app_initializer_error_type',
        error.runtimeType.toString(),
      ),
    );
    if (error is PlatformException) {
      unawaited(
        FirebaseCrashlytics.instance.setCustomKey(
          'app_initializer_platform_code',
          error.code,
        ),
      );
      unawaited(
        FirebaseCrashlytics.instance.setCustomKey(
          'app_initializer_platform_message',
          error.message ?? '',
        ),
      );
    }
    FirebaseCrashlytics.instance.recordError(
      error,
      stack,
      fatal: !_isRecoverableInitializerFailure(error),
    );
  }

  static bool _isRecoverableInitializerFailure(Object error) {
    final message = error.toString();
    if (message.contains('Secure storage unavailable')) return true;
    if (error is PlatformException) {
      return error.code == 'StepDetection' ||
          error.message?.contains('StepDetection not available') == true ||
          error.message?.contains('not available on this device') == true;
    }
    return false;
  }

  static void _logFirebaseInitFailure(Object error) {
    debugPrint('❌ Firebase initialization failed');
    debugPrint('❌ Firebase: type=${error.runtimeType}');
    if (error is PlatformException) {
      debugPrint('❌ Firebase: platformCode=${error.code}');
      debugPrint('❌ Firebase: platformMessage=${error.message}');
      debugPrint('❌ Firebase: platformDetails=${error.details}');
      if (error.code == 'channel-error') {
        _logNativePluginChannelFailure('Firebase');
      }
    } else if (error is TimeoutException) {
      debugPrint('❌ Firebase: timeout=${error.message}');
    } else {
      debugPrint('❌ Firebase: error=$error');
    }
    debugPrint('❌ Firebase: appsAfterFailure=${Firebase.apps.length}');
  }

  static void _logNativePluginChannelFailure(String source) {
    debugPrint(
      '❌ $source: native plugin channel unavailable; verify Android '
      'GeneratedPluginRegistrant.registerWith() ran.',
    );
  }

  static Future<void> _initHive() async {
    await Hive.initFlutter();

    // Register Adapters
    if (!Hive.isAdapterRegistered(0)) Hive.registerAdapter(MacrosAdapter());
    if (!Hive.isAdapterRegistered(1)) Hive.registerAdapter(MealAdapter());
    if (!Hive.isAdapterRegistered(2)) {
      Hive.registerAdapter(UserSettingsAdapter());
    }
    if (!Hive.isAdapterRegistered(3)) Hive.registerAdapter(WaterLogAdapter());
    if (!Hive.isAdapterRegistered(4)) Hive.registerAdapter(BodyMetricAdapter());
    if (!Hive.isAdapterRegistered(5)) {
      Hive.registerAdapter(GroceryItemAdapter());
    }
    if (!Hive.isAdapterRegistered(6)) Hive.registerAdapter(MealPlanAdapter());
    if (!Hive.isAdapterRegistered(10)) {
      Hive.registerAdapter(TemplateItemAdapter());
    }
    if (!Hive.isAdapterRegistered(11)) {
      Hive.registerAdapter(MealTemplateAdapter());
    }
    if (!Hive.isAdapterRegistered(12)) {
      Hive.registerAdapter(AchievementAdapter());
    }

    debugPrint('📦 Hive initialized');
  }
}
