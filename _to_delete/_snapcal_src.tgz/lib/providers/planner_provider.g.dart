// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'planner_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$plannerHash() => r'9e363ae712b2b5da8bd0d91e6c49c280987032fd';

/// See also [Planner].
@ProviderFor(Planner)
final plannerProvider = AsyncNotifierProvider<Planner, void>.internal(
  Planner.new,
  name: r'plannerProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$plannerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Planner = AsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
