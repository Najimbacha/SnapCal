// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'water_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$waterHash() => r'859d3bdca9539e5972c030f4917d70af54b90d68';

/// See also [Water].
@ProviderFor(Water)
final waterProvider = AsyncNotifierProvider<Water, WaterState>.internal(
  Water.new,
  name: r'waterProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$waterHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Water = AsyncNotifier<WaterState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
