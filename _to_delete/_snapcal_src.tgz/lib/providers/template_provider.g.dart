// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'template_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$templatesHash() => r'83d71c14ac6f79753c1a5d85e7fe0996d955c057';

/// See also [Templates].
@ProviderFor(Templates)
final templatesProvider =
    AsyncNotifierProvider<Templates, List<MealTemplate>>.internal(
      Templates.new,
      name: r'templatesProvider',
      debugGetCreateSourceHash:
          const bool.fromEnvironment('dart.vm.product')
              ? null
              : _$templatesHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$Templates = AsyncNotifier<List<MealTemplate>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
