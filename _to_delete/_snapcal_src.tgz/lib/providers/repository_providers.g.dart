// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'repository_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$settingsRepositoryHash() =>
    r'a23f341891c165e2bfa99f72eb149b66f296f64b';

/// See also [settingsRepository].
@ProviderFor(settingsRepository)
final settingsRepositoryProvider = FutureProvider<SettingsRepository>.internal(
  settingsRepository,
  name: r'settingsRepositoryProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$settingsRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef SettingsRepositoryRef = FutureProviderRef<SettingsRepository>;
String _$mealRepositoryHash() => r'b260657ed0d644f988416039b009b05909843b94';

/// See also [mealRepository].
@ProviderFor(mealRepository)
final mealRepositoryProvider = FutureProvider<MealRepository>.internal(
  mealRepository,
  name: r'mealRepositoryProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$mealRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef MealRepositoryRef = FutureProviderRef<MealRepository>;
String _$waterRepositoryHash() => r'75e5e75dc37a852fb483ede21c8a82dd09543c4a';

/// See also [waterRepository].
@ProviderFor(waterRepository)
final waterRepositoryProvider = FutureProvider<WaterRepository>.internal(
  waterRepository,
  name: r'waterRepositoryProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$waterRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef WaterRepositoryRef = FutureProviderRef<WaterRepository>;
String _$assistantRepositoryHash() =>
    r'ada257224d92b53ddd4eeefbd4f3f009b3867495';

/// See also [assistantRepository].
@ProviderFor(assistantRepository)
final assistantRepositoryProvider =
    FutureProvider<AssistantRepository>.internal(
      assistantRepository,
      name: r'assistantRepositoryProvider',
      debugGetCreateSourceHash:
          const bool.fromEnvironment('dart.vm.product')
              ? null
              : _$assistantRepositoryHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef AssistantRepositoryRef = FutureProviderRef<AssistantRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
