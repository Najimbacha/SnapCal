// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'widget_sync_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$widgetSyncHash() => r'4af75af25b31f5a8cb216391f4e11f4938bea267';

/// See also [WidgetSync].
@ProviderFor(WidgetSync)
final widgetSyncProvider = AsyncNotifierProvider<WidgetSync, void>.internal(
  WidgetSync.new,
  name: r'widgetSyncProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$widgetSyncHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$WidgetSync = AsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
