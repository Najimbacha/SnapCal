// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'settings_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$effectiveIsProHash() => r'8d5fe9e2c10f5e7fc9d154bd3b534eebaba87df0';

/// Combines real Pro status with debug override.
/// In debug mode, the debug override can toggle Pro features on/off.
///
/// Copied from [effectiveIsPro].
@ProviderFor(effectiveIsPro)
final effectiveIsProProvider = Provider<bool>.internal(
  effectiveIsPro,
  name: r'effectiveIsProProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$effectiveIsProHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef EffectiveIsProRef = ProviderRef<bool>;
String _$debugProOverrideHash() => r'930aa40d763638daf16900ecce17f11e3c275311';

/// See also [DebugProOverride].
@ProviderFor(DebugProOverride)
final debugProOverrideProvider =
    NotifierProvider<DebugProOverride, bool>.internal(
      DebugProOverride.new,
      name: r'debugProOverrideProvider',
      debugGetCreateSourceHash:
          const bool.fromEnvironment('dart.vm.product')
              ? null
              : _$debugProOverrideHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$DebugProOverride = Notifier<bool>;
String _$settingsHash() => r'a05fc18d525cb06a5d2234f5d48db8e4f7a6e5c2';

/// See also [Settings].
@ProviderFor(Settings)
final settingsProvider = AsyncNotifierProvider<Settings, UserSettings>.internal(
  Settings.new,
  name: r'settingsProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$settingsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Settings = AsyncNotifier<UserSettings>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
