// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'phone_auth_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$verificationIdHash() => r'743c67e500d3fddb675900afb6bfea9cd5b6614c';

/// See also [VerificationId].
@ProviderFor(VerificationId)
final verificationIdProvider =
    NotifierProvider<VerificationId, String?>.internal(
      VerificationId.new,
      name: r'verificationIdProvider',
      debugGetCreateSourceHash:
          const bool.fromEnvironment('dart.vm.product')
              ? null
              : _$verificationIdHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$VerificationId = Notifier<String?>;
String _$phoneAuthHash() => r'ae0c2b3388f883e277f838b4ab4bcc7852b860ed';

/// See also [PhoneAuth].
@ProviderFor(PhoneAuth)
final phoneAuthProvider = AsyncNotifierProvider<PhoneAuth, void>.internal(
  PhoneAuth.new,
  name: r'phoneAuthProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$phoneAuthHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PhoneAuth = AsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
