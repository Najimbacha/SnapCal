// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'assistant_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$assistantHash() => r'7fbf41eefd50c8e94ae5de082d6edf8309833b0d';

/// See also [Assistant].
@ProviderFor(Assistant)
final assistantProvider = AsyncNotifierProvider<Assistant, void>.internal(
  Assistant.new,
  name: r'assistantProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$assistantHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Assistant = AsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
