// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'subscription_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$subscriptionInfoHash() => r'91f7946ef224e966943efa0be98d1df68b12fd72';

/// See also [subscriptionInfo].
@ProviderFor(subscriptionInfo)
final subscriptionInfoProvider = FutureProvider<CustomerInfo>.internal(
  subscriptionInfo,
  name: r'subscriptionInfoProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$subscriptionInfoHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef SubscriptionInfoRef = FutureProviderRef<CustomerInfo>;
String _$isPremiumHash() => r'723ba3b990f218983ab122c0f7a6514d745c44e3';

/// See also [isPremium].
@ProviderFor(isPremium)
final isPremiumProvider = Provider<bool>.internal(
  isPremium,
  name: r'isPremiumProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$isPremiumHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef IsPremiumRef = ProviderRef<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
