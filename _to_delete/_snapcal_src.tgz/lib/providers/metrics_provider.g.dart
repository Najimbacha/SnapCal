// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'metrics_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$bodyMetricsHash() => r'08f29522922f6152575077a6b41ef9ff957da24a';

/// See also [BodyMetrics].
@ProviderFor(BodyMetrics)
final bodyMetricsProvider =
    AsyncNotifierProvider<BodyMetrics, List<BodyMetric>>.internal(
      BodyMetrics.new,
      name: r'bodyMetricsProvider',
      debugGetCreateSourceHash:
          const bool.fromEnvironment('dart.vm.product')
              ? null
              : _$bodyMetricsHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$BodyMetrics = AsyncNotifier<List<BodyMetric>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
