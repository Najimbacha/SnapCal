// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'meal_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$todaysMealsHash() => r'89725b8dcd9a6f2367d9cd1e90fdec28e77f2165';

/// Stream provider for today's meals
///
/// Copied from [todaysMeals].
@ProviderFor(todaysMeals)
final todaysMealsProvider = StreamProvider<List<Meal>>.internal(
  todaysMeals,
  name: r'todaysMealsProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$todaysMealsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef TodaysMealsRef = StreamProviderRef<List<Meal>>;
String _$selectedDateHash() => r'30d539d2c761c185e7b9880f2a2a8f82706e8ce8';

/// Current selected date for browsing
///
/// Copied from [SelectedDate].
@ProviderFor(SelectedDate)
final selectedDateProvider = NotifierProvider<SelectedDate, String>.internal(
  SelectedDate.new,
  name: r'selectedDateProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$selectedDateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SelectedDate = Notifier<String>;
String _$mealLogHash() => r'58044bd90570b302176dce6d839572e552d01ddd';

/// See also [MealLog].
@ProviderFor(MealLog)
final mealLogProvider = AsyncNotifierProvider<MealLog, void>.internal(
  MealLog.new,
  name: r'mealLogProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$mealLogHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MealLog = AsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
