// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'achievements_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$achievementsHash() => r'eba3cbd65590708bc78202e8f3e86d66bef747d9';

/// See also [Achievements].
@ProviderFor(Achievements)
final achievementsProvider =
    AsyncNotifierProvider<Achievements, List<Achievement>>.internal(
      Achievements.new,
      name: r'achievementsProvider',
      debugGetCreateSourceHash:
          const bool.fromEnvironment('dart.vm.product')
              ? null
              : _$achievementsHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$Achievements = AsyncNotifier<List<Achievement>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
