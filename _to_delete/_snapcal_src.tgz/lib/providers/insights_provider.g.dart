// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'insights_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$insightsHash() => r'b4a48137833c86b517cc975e9ddaebf5f1cecbd6';

/// See also [Insights].
@ProviderFor(Insights)
final insightsProvider =
    AsyncNotifierProvider<Insights, WeeklyReport?>.internal(
      Insights.new,
      name: r'insightsProvider',
      debugGetCreateSourceHash:
          const bool.fromEnvironment('dart.vm.product') ? null : _$insightsHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$Insights = AsyncNotifier<WeeklyReport?>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
