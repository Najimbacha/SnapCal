// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'activity_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$activityHash() => r'3346d763306745b50c106669ef67043ca026f451';

/// See also [Activity].
@ProviderFor(Activity)
final activityProvider =
    AsyncNotifierProvider<Activity, ActivitySummary>.internal(
      Activity.new,
      name: r'activityProvider',
      debugGetCreateSourceHash:
          const bool.fromEnvironment('dart.vm.product') ? null : _$activityHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$Activity = AsyncNotifier<ActivitySummary>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
