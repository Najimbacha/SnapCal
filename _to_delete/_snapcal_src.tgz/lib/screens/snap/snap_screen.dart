import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:shimmer/shimmer.dart';

import '../../core/theme/app_typography.dart';
import '../../data/models/meal.dart';
import '../../data/models/user_settings.dart';
import '../../data/services/connectivity_service.dart';
import '../../data/services/gemini_service.dart';
import '../../data/services/premium_conversion_service.dart';
import '../../providers/meal_provider.dart';
import '../../providers/settings_provider.dart';
import 'snap_controller.dart';
import 'widgets/analyzing_overlay.dart';
import 'widgets/barcode_scanner_view.dart';
import 'widgets/result_modal.dart';
import 'widgets/shutter_button.dart';
import 'package:snapcal/l10n/generated/app_localizations.dart';
import '../../data/services/camera_service.dart';
import '../../router.dart';

enum SnapInitialMode { food, barcode }

class SnapScreen extends ConsumerStatefulWidget {
  final SnapInitialMode initialMode;

  const SnapScreen({super.key, this.initialMode = SnapInitialMode.food});

  @override
  ConsumerState<SnapScreen> createState() => _SnapScreenState();
}

class _SnapScreenState extends ConsumerState<SnapScreen>
    with WidgetsBindingObserver, RouteAware, TickerProviderStateMixin {
  late final SnapController _controller;
  bool _hasInitializedOnce = false;
  bool _isTickerActive = true;
  bool _isSavingResult = false;
  String? _savedResultFingerprint;

  Offset? _focusPoint;
  AnimationController? _focusAnimController;
  Animation<double>? _focusOpacity;
  Animation<double>? _focusScale;

  @override
  void initState() {
    super.initState();
    _controller = SnapController()..onStateChanged = () => setState(() {});
    WidgetsBinding.instance.addObserver(this);

    _focusAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _focusOpacity = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(
        parent: _focusAnimController!,
        curve: const Interval(0.5, 1.0),
      ),
    );
    _focusScale = Tween<double>(begin: 1.4, end: 1.0).animate(
      CurvedAnimation(
        parent: _focusAnimController!,
        curve: Curves.easeOutCubic,
      ),
    );
  }

  @override
  void didUpdateWidget(covariant SnapScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.initialMode == widget.initialMode) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startLaunchMode();
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final modalRoute = ModalRoute.of(context);
    if (modalRoute != null) {
      routeObserver.subscribe(this, modalRoute as ModalRoute<dynamic>);
    }

    final tickerActive = TickerMode.valuesOf(context).enabled;
    if (_isTickerActive != tickerActive) {
      _isTickerActive = tickerActive;
      if (!tickerActive) {
        CameraService().stop();
      } else if (_hasInitializedOnce) {
        _startLaunchMode();
      }
    }

    if (_hasInitializedOnce) return;
    _hasInitializedOnce = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startLaunchMode();
    });
  }

  void _startLaunchMode() {
    if (!mounted || !_isTickerActive) return;
    if (widget.initialMode == SnapInitialMode.barcode) {
      _controller.isScanningBarcode = true;
      return;
    }
    if (_controller.isScanningBarcode) {
      _controller.isScanningBarcode = false;
    } else {
      _controller.initializeCamera();
    }
  }

  @override
  void dispose() {
    routeObserver.unsubscribe(this);
    WidgetsBinding.instance.removeObserver(this);
    _focusAnimController?.dispose();
    _controller.onStateChanged = null;
    _controller.dispose();
    CameraService().stop(); // Stop camera when leaving the screen
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _controller.initializeCamera();
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      CameraService().stop();
    }
  }

  @override
  void didPushNext() {
    CameraService().stop();
  }

  @override
  void didPopNext() {
    _controller.initializeCamera();
  }

  void _showPaywall() {
    PremiumConversionService().openPaywall(
      context,
      PaywallEntryPoint.scanLimit,
      limitReached: true,
      featureName: 'scan',
    );
  }

  void _showResultModal() {
    if (!mounted) return;
    _isSavingResult = false;
    _savedResultFingerprint = null;
    final results = _controller.analysisResults;

    Navigator.of(context, rootNavigator: true).push(
      PageRouteBuilder(
        opaque: true,
        barrierDismissible: false,
        barrierColor: Colors.black.withValues(alpha: 0.3),
        pageBuilder: (context, animation, secondaryAnimation) {
          return FadeTransition(
            opacity: animation,
            child: ResultModal(
              imageBytes: _controller.capturedImageBytes,
              result:
                  results != null && results.length == 1 ? results.first : null,
              results: results != null && results.length > 1 ? results : null,
              onSave: _saveMeal,
              onSaveAll: _saveMultipleMeals,
              onCancel: _controller.reset,
            ),
          );
        },
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0, 0.08),
              end: Offset.zero,
            ).animate(
              CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
            ),
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 300),
      ),
    );
  }

  void _showManualInputModal() {
    if (!mounted) return;
    _isSavingResult = false;
    _savedResultFingerprint = null;
    Navigator.of(context, rootNavigator: true).push(
      PageRouteBuilder(
        opaque: true,
        barrierDismissible: false,
        barrierColor: Colors.black.withValues(alpha: 0.3),
        pageBuilder: (context, animation, secondaryAnimation) {
          return FadeTransition(
            opacity: animation,
            child: ResultModal(
              imageBytes: _controller.capturedImageBytes,
              result: null,
              onSave: _saveMeal,
              onSaveAll: _saveMultipleMeals,
              onCancel: _controller.reset,
            ),
          );
        },
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0, 0.08),
              end: Offset.zero,
            ).animate(
              CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
            ),
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 300),
      ),
    );
  }

  Future<void> _saveMeal(
    String name,
    int calories,
    int protein,
    int carbs,
    int fat,
    String? portion,
  ) async {
    final fingerprint = _singleSaveFingerprint(
      name: name,
      calories: calories,
      protein: protein,
      carbs: carbs,
      fat: fat,
      portion: portion,
    );
    if (!_beginResultSave(fingerprint)) return;

    final mealNotifier = ref.read(mealLogProvider.notifier);
    final router = GoRouter.of(context);
    final now = DateTime.now();
    final dateString =
        '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';

    try {
      HapticFeedback.heavyImpact();
      router.go('/');

      await mealNotifier.addMeal(
        Meal(
          id: mealNotifier.generateMealId(),
          timestamp: now.millisecondsSinceEpoch,
          dateString: dateString,
          foodName:
              name.isEmpty
                  ? AppLocalizations.of(context)!.log_unknown_food
                  : name,
          calories: calories,
          macros: Macros(protein: protein, carbs: carbs, fat: fat),
          portion: portion,
          scanConfidence: 0.82,
          scanSource: 'ai_scan',
          aiRationale:
              'Estimated from the photo, visible portion size, and macro balance. Review the portion before logging.',
          originalCalories: calories,
        ),
      );

      _controller.reset();
    } finally {
      _isSavingResult = false;
    }
  }

  Future<void> _saveMultipleMeals(List<NutritionResult> selectedItems) async {
    final fingerprint = _multiSaveFingerprint(selectedItems);
    if (!_beginResultSave(fingerprint)) return;

    final mealNotifier = ref.read(mealLogProvider.notifier);
    final router = GoRouter.of(context);
    final now = DateTime.now();
    final dateString =
        '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';

    try {
      HapticFeedback.heavyImpact();
      router.go('/');

      for (final item in selectedItems) {
        await mealNotifier.addMeal(
          Meal(
            id: mealNotifier.generateMealId(),
            timestamp: DateTime.now().millisecondsSinceEpoch,
            dateString: dateString,
            foodName:
                item.foodName.isEmpty
                    ? AppLocalizations.of(context)!.log_unknown_food
                    : item.foodName,
            calories: item.calories,
            macros: Macros(
              protein: item.protein,
              carbs: item.carbs,
              fat: item.fat,
            ),
            portion: item.portion,
            scanConfidence: item.confidence ?? 0.82,
            scanSource: 'ai_scan',
            aiRationale:
                'Estimated from the photo, visible portion size, and macro balance. Review the portion before logging.',
            originalCalories: item.calories,
            weightG: item.weightG,
            nutritionMatchId: item.nutritionMatchId,
            nutritionPer100g: item.nutritionPer100g,
          ),
        );
      }

      _controller.reset();
    } finally {
      _isSavingResult = false;
    }
  }

  bool _beginResultSave(String fingerprint) {
    if (_isSavingResult || _savedResultFingerprint == fingerprint) {
      return false;
    }
    _isSavingResult = true;
    _savedResultFingerprint = fingerprint;
    return true;
  }

  String _singleSaveFingerprint({
    required String name,
    required int calories,
    required int protein,
    required int carbs,
    required int fat,
    required String? portion,
  }) {
    final imageKey = _controller.capturedImageBytes?.length ?? 0;
    return [
      'single',
      imageKey,
      name.trim().toLowerCase(),
      calories,
      protein,
      carbs,
      fat,
      portion?.trim().toLowerCase() ?? '',
    ].join('|');
  }

  String _multiSaveFingerprint(List<NutritionResult> items) {
    final imageKey = _controller.capturedImageBytes?.length ?? 0;
    return [
      'multi',
      imageKey,
      ...items.map(
        (item) => [
          item.foodName.trim().toLowerCase(),
          item.calories,
          item.protein,
          item.carbs,
          item.fat,
          item.portion.trim().toLowerCase(),
        ].join(':'),
      ),
    ].join('|');
  }

  @override
  Widget build(BuildContext context) {
    final topSafe = MediaQuery.of(context).padding.top;
    final bottomSafe = MediaQuery.of(context).padding.bottom;
    const previewH = 16.0;
    const cornerRadius = 28.0;

    final cameraContent = <Widget>[];

    if (_controller.isScanningBarcode) {
      cameraContent.add(
        BarcodeScannerView(
          onBarcodeDetected:
              (code) => _controller.handleBarcodeDetected(
                code,
                context: context,
                settingsProvider:
                    ref.read(settingsProvider).valueOrNull ??
                    UserSettings.defaults(),
                connectivity: ConnectivityService(),
                onShowPaywall: _showPaywall,
                onShowResult: _showResultModal,
                onShowManualInput: _showManualInputModal,
              ),
          onCancel: () => context.go('/'),
        ),
      );
    } else if (_controller.isInitialized &&
        _controller.cameraController != null) {
      cameraContent.add(
        GestureDetector(
          onTapUp: (details) {
            HapticFeedback.selectionClick();
            final box = context.findRenderObject() as RenderBox;
            final size = box.size;
            final point = Offset(
              details.localPosition.dx / size.width,
              details.localPosition.dy / size.height,
            );
            _controller.setFocusPoint(point);
            setState(() => _focusPoint = details.localPosition);
            _focusAnimController?.reset();
            _focusAnimController?.forward();
          },
          child:
              (_controller.cameraController?.value.isInitialized ?? false)
                  ? CameraPreview(
                    _controller.cameraController!,
                    key: ObjectKey(_controller.cameraController),
                  )
                  : const _CameraShimmerSkeleton(),
        ),
      );
    } else if (_controller.errorMessage != null) {
      cameraContent.add(
        _StatePanel(
          icon: LucideIcons.cameraOff,
          title: AppLocalizations.of(context)!.error_camera,
          body: _controller.errorMessage!,
          actionLabel: AppLocalizations.of(context)!.assistant_retry,
          onAction: _controller.initializeCamera,
        ),
      );
    } else {
      cameraContent.add(const _CameraShimmerSkeleton());
    }

    return Scaffold(
      backgroundColor: const Color(0xFF000000),
      body: Stack(
        children: [
          // ── Rounded camera preview area ──
          Positioned(
            top: topSafe + 56,
            left: previewH,
            right: previewH,
            bottom: 210 + bottomSafe,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(cornerRadius),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(cornerRadius),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.10),
                    width: 0.5,
                  ),
                ),
                child: Stack(
                  children: [
                    ...cameraContent,
                    // Tap-to-focus ring
                    if (_focusPoint != null && _focusAnimController != null)
                      AnimatedBuilder(
                        animation: _focusAnimController!,
                        builder: (context, _) {
                          return Positioned(
                            left: _focusPoint!.dx - 30,
                            top: _focusPoint!.dy - 30,
                            child: Opacity(
                              opacity: _focusOpacity?.value ?? 0,
                              child: Transform.scale(
                                scale: _focusScale?.value ?? 1.0,
                                child: Container(
                                  width: 60,
                                  height: 60,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: const Color(0xFFFFD700),
                                      width: 2,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                  ],
                ),
              ),
            ),
          ),

          // ── Bottom gradient for readability ──
          if (!_controller.isScanningBarcode)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              height: 200,
              child: IgnorePointer(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withValues(alpha: 0.60),
                      ],
                    ),
                  ),
                ),
              ),
            ),

          // ── Top bar ──
          if (!_controller.isScanningBarcode)
            Positioned(
              top: topSafe + 12,
              left: 16,
              right: 16,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () => context.go('/'),
                    child: Container(
                      width: 40,
                      height: 40,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.30),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        LucideIcons.x,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                  if (_controller.isInitialized &&
                      _controller.errorMessage == null)
                    GestureDetector(
                      onTap: _controller.toggleFlash,
                      child: Container(
                        width: 40,
                        height: 40,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.30),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _controller.flashMode == FlashMode.off
                              ? LucideIcons.zapOff
                              : LucideIcons.zap,
                          color:
                              _controller.flashMode == FlashMode.off
                                  ? Colors.white54
                                  : const Color(0xFFFFD700),
                          size: 20,
                        ),
                      ),
                    ),
                ],
              ),
            ),

          // ── Bottom controls ──
          if (!_controller.isScanningBarcode)
            Positioned(
              left: 0,
              right: 0,
              bottom: bottomSafe + 72,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      // Gallery
                      Expanded(
                        child: GestureDetector(
                          onTap:
                              () => _controller.pickFromGallery(
                                context: context,
                                mealProvider: ref.read(
                                  mealLogProvider.notifier,
                                ),
                                settingsProvider:
                                    ref.read(settingsProvider).valueOrNull ??
                                    UserSettings.defaults(),
                                isPro: ref.read(effectiveIsProProvider),
                                connectivity: ConnectivityService(),
                                onShowPaywall: _showPaywall,
                                onShowResult: _showResultModal,
                                onShowManualInput: _showManualInputModal,
                              ),
                          child: const _BottomIcon(
                            icon: LucideIcons.image,
                            label: 'Gallery',
                          ),
                        ),
                      ),
                      // Shutter
                      ShutterButton(
                        onPressed:
                            () => _controller.captureAndAnalyze(
                              context: context,
                              mealProvider: ref.read(mealLogProvider.notifier),
                              settingsProvider:
                                  ref.read(settingsProvider).valueOrNull ??
                                  UserSettings.defaults(),
                              isPro: ref.read(effectiveIsProProvider),
                              connectivity: ConnectivityService(),
                              onShowPaywall: _showPaywall,
                              onShowResult: _showResultModal,
                              onShowManualInput: _showManualInputModal,
                            ),
                        isLoading: _controller.isCapturing,
                      ),
                      // Barcode
                      Expanded(
                        child: GestureDetector(
                          onTap: () => _controller.isScanningBarcode = true,
                          child: const _BottomIcon(
                            icon: LucideIcons.scanLine,
                            label: 'Barcode',
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  // Manual search escape hatch (Case D)
                  GestureDetector(
                    onTap: _showManualInputModal,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.10),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.15),
                          width: 0.5,
                        ),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            LucideIcons.type,
                            color: Colors.white70,
                            size: 14,
                          ),
                          SizedBox(width: 6),
                          Text(
                            'Type Ingredient',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

          // ── Analyzing overlay ──
          if (_controller.isAnalyzing)
            Positioned.fill(
              child: AnalyzingOverlay(
                controller: _controller,
                onManualEntry: _showManualInputModal,
              ),
            ),
        ],
      ),
    );
  }
}

class _CameraShimmerSkeleton extends StatelessWidget {
  const _CameraShimmerSkeleton();

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: const Color(0xFF121212), // Charcoal base
      highlightColor: const Color(0xFF1E1E1E), // Lighter highlight
      child: Container(
        color: Colors.black,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.1),
                    width: 2,
                  ),
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
              const SizedBox(height: 40),
              Container(
                width: 150,
                height: 12,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BottomIcon extends StatelessWidget {
  final IconData icon;
  final String label;

  const _BottomIcon({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 56,
          height: 56,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.10),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: Colors.white, size: 24),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: const TextStyle(
            color: Color(0xD9FFFFFF),
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

class _StatePanel extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;
  final String? actionLabel;
  final VoidCallback? onAction;

  const _StatePanel({
    required this.icon,
    required this.title,
    required this.body,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        margin: const EdgeInsets.all(32),
        padding: const EdgeInsets.all(32),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1C1E),
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.white, size: 48),
            const SizedBox(height: 24),
            Text(
              title,
              style: AppTypography.headlineSmall.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w800,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              body,
              style: AppTypography.bodyMedium.copyWith(
                color: Colors.white.withValues(alpha: 0.7),
              ),
              textAlign: TextAlign.center,
            ),
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 24),
              FilledButton(onPressed: onAction, child: Text(actionLabel!)),
            ],
          ],
        ),
      ),
    );
  }
}
