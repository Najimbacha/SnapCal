// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_settings.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class UserSettingsAdapter extends TypeAdapter<UserSettings> {
  @override
  final int typeId = 2;

  @override
  UserSettings read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return UserSettings(
      dailyCalorieGoal: fields[0] as int,
      dailyProteinGoal: fields[1] as int,
      dailyCarbGoal: fields[2] as int,
      dailyFatGoal: fields[3] as int,
      isPro: fields[4] as bool,
      currentStreak: fields[5] as int,
      lastLoggedDate: fields[6] as String?,
      notificationsEnabled: fields[7] as bool,
      mealRemindersEnabled: fields[8] as bool,
      goalAlertsEnabled: fields[9] as bool,
      breakfastTime: fields[10] as String,
      lunchTime: fields[11] as String,
      dinnerTime: fields[12] as String,
      height: fields[13] as double?,
      targetWeight: fields[14] as double?,
      themeMode: fields[15] as String,
      onboardingComplete: fields[16] as bool,
      age: fields[17] as int?,
      gender: fields[18] as String?,
      activityLevel: fields[19] as String?,
      goalTimelineMonths: fields[20] as int?,
      startingWeight: fields[21] as double?,
      weightUnit: fields[22] as String?,
      heightUnit: fields[23] as String?,
      goalMode: fields[24] as String?,
      weeklyRateKg: fields[25] as double?,
      recommendationInsight: fields[26] as String?,
      recommendationTip: fields[27] as String?,
      recommendationSafetyNote: fields[28] as String?,
      mealsPerDay: fields[29] as int?,
      dietaryRestriction: fields[30] as String?,
      cuisinePreference: fields[31] as String?,
      dailyMotivationEnabled: fields[33] as bool? ?? false,
      lastOpenedDate: fields[34] as String?,
      foodDislikes: fields[35] as String?,
      medicalNotes: fields[36] as String?,
      foodRemindersEnabled: fields[37] as bool? ?? false,
      lastFoodReminderDate: fields[38] as String?,
      fcmToken: fields[39] as String?,
      languageCode: fields[32] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, UserSettings obj) {
    writer
      ..writeByte(40)
      ..writeByte(0)
      ..write(obj.dailyCalorieGoal)
      ..writeByte(1)
      ..write(obj.dailyProteinGoal)
      ..writeByte(2)
      ..write(obj.dailyCarbGoal)
      ..writeByte(3)
      ..write(obj.dailyFatGoal)
      ..writeByte(4)
      ..write(obj.isPro)
      ..writeByte(5)
      ..write(obj.currentStreak)
      ..writeByte(6)
      ..write(obj.lastLoggedDate)
      ..writeByte(7)
      ..write(obj.notificationsEnabled)
      ..writeByte(8)
      ..write(obj.mealRemindersEnabled)
      ..writeByte(9)
      ..write(obj.goalAlertsEnabled)
      ..writeByte(10)
      ..write(obj.breakfastTime)
      ..writeByte(11)
      ..write(obj.lunchTime)
      ..writeByte(12)
      ..write(obj.dinnerTime)
      ..writeByte(13)
      ..write(obj.height)
      ..writeByte(14)
      ..write(obj.targetWeight)
      ..writeByte(15)
      ..write(obj.themeMode)
      ..writeByte(16)
      ..write(obj.onboardingComplete)
      ..writeByte(17)
      ..write(obj.age)
      ..writeByte(18)
      ..write(obj.gender)
      ..writeByte(19)
      ..write(obj.activityLevel)
      ..writeByte(20)
      ..write(obj.goalTimelineMonths)
      ..writeByte(21)
      ..write(obj.startingWeight)
      ..writeByte(22)
      ..write(obj.weightUnit)
      ..writeByte(23)
      ..write(obj.heightUnit)
      ..writeByte(24)
      ..write(obj.goalMode)
      ..writeByte(25)
      ..write(obj.weeklyRateKg)
      ..writeByte(26)
      ..write(obj.recommendationInsight)
      ..writeByte(27)
      ..write(obj.recommendationTip)
      ..writeByte(28)
      ..write(obj.recommendationSafetyNote)
      ..writeByte(29)
      ..write(obj.mealsPerDay)
      ..writeByte(30)
      ..write(obj.dietaryRestriction)
      ..writeByte(31)
      ..write(obj.cuisinePreference)
      ..writeByte(32)
      ..write(obj.languageCode)
      ..writeByte(33)
      ..write(obj.dailyMotivationEnabled)
      ..writeByte(34)
      ..write(obj.lastOpenedDate)
      ..writeByte(35)
      ..write(obj.foodDislikes)
      ..writeByte(36)
      ..write(obj.medicalNotes)
      ..writeByte(37)
      ..write(obj.foodRemindersEnabled)
      ..writeByte(38)
      ..write(obj.lastFoodReminderDate)
      ..writeByte(39)
      ..write(obj.fcmToken);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is UserSettingsAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
